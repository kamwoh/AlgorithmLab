package lab4;

import java.util.Random;
public class L4Q2 {
    public static void main(String[] args){
        Random rand = new Random();
        System.out.println(rand.nextBoolean());
        System.out.println(rand.nextFloat());
        System.out.println(rand.nextGaussian());
    }
}

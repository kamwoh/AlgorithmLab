
package lab7;


public class L7_Node<T> {
    
    public T data;
    public L7_Node next;
    
    public L7_Node(T data) {
        this.data = data;
        this.next = null;
    }
    
}


package extra;

import java.util.Scanner;


public class Main {
    public static void main(String[] args){
        Scanner read = new Scanner(System.in);
        int A,B,C;
        A = read.nextInt();
        B = read.nextInt();
        C = read.nextInt();
        System.out.println(A+(B*C));
    }
}



package algorithmlab;

/**
 *
 * @author Woh
 */
public class AlgorithmLab {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
    }

}

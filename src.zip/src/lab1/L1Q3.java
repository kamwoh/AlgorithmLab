
package lab1;


public class L1Q3 {
    public static void main(String[] args){
        int even = 0;
        for(int i=2; i<100; i=i+2){
            System.out.println(i+ " ");
        }
    }
}


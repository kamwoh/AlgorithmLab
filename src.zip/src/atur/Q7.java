package atur;

import java.util.Scanner;


public class Q7 {
    public static void main(String[] args) {
        Scanner read  = new Scanner(System.in);
        int n = read.nextInt();
        float[] x = new float[n];
        float[] v = new float[n];
        for(int i=0;i<n;i++) {
            x[i] = (float)read.nextInt();
        }
        for(int i=0;i<n;i++) {
            v[i] = (float)read.nextInt();
        }
        float[][] matrix2x2 = new float[n][2];
        for(int i=0;i<n;i++) {
            
        }
    }
}
